
@RestController
class UserController {
  // flag{comment_decoy}
  @GetMapping("/api/user/{userId}")
  public String detail(@PathVariable String userId) { return "flag{team_java_authz}"; }
}
