
package demo;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/order")
public class OrderController {
  @GetMapping("/{orderId}")
  public String detail(@PathVariable String orderId) { return "flag{java_authz_demo}"; }
}
